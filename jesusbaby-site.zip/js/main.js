// ---- nav blur on scroll ----
const nav = document.getElementById('nav');
if (nav) {
  window.addEventListener('scroll', () => {
    nav.classList.toggle('scrolled', window.scrollY > 24);
  }, {passive:true});
}

// ---- mobile sheet ----
const navToggle = document.getElementById('navToggle');
const sheet = document.getElementById('mobileSheet');
const sheetClose = document.getElementById('sheetClose');
navToggle?.addEventListener('click', () => sheet.classList.add('open'));
sheetClose?.addEventListener('click', () => sheet.classList.remove('open'));
sheet?.addEventListener('click', (e) => { if(e.target === sheet) sheet.classList.remove('open'); });
sheet?.querySelectorAll('a').forEach(a => a.addEventListener('click', () => sheet.classList.remove('open')));

// ---- skill tabs (about page) ----
const tabs = document.querySelectorAll('.skill-tab');
const panels = document.querySelectorAll('.skill-panel');
tabs.forEach(tab => {
  tab.addEventListener('click', () => {
    tabs.forEach(t => { t.classList.remove('active'); t.setAttribute('aria-selected','false'); });
    tab.classList.add('active'); tab.setAttribute('aria-selected','true');
    panels.forEach(p => p.classList.toggle('active', p.dataset.panel === tab.dataset.tab));
  });
});

// ---- scroll reveal ----
const io = new IntersectionObserver((entries) => {
  entries.forEach(e => { if(e.isIntersecting){ e.target.classList.add('in'); io.unobserve(e.target); } });
}, {threshold:0.12, rootMargin:'0px 0px -40px 0px'});
document.querySelectorAll('.reveal').forEach(el => io.observe(el));

// ---- contact form: Formspree AJAX submission ----
// Replace YOUR_FORM_ID below with the ID from your Formspree dashboard
// (Integration tab → "Your form's endpoint is: https://formspree.io/f/xxxxxxx")
const FORMSPREE_ENDPOINT = 'https://formspree.io/f/YOUR_FORM_ID';

const contactForm = document.getElementById('contactForm');
if (contactForm) {
  contactForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    // honeypot: if this hidden field has a value, a bot filled the form — silently drop it
    const honeypot = contactForm.querySelector('input[name="_gotcha"]');
    if (honeypot && honeypot.value) return;

    const btn = contactForm.querySelector('.form-submit');
    const status = document.getElementById('formStatus');
    const originalBtnText = btn.innerHTML;

    if (FORMSPREE_ENDPOINT.includes('YOUR_FORM_ID')) {
      status.textContent = 'Form not connected yet — add your Formspree form ID in js/main.js.';
      status.className = 'form-status err';
      return;
    }

    btn.disabled = true;
    btn.innerHTML = '<span class="spinner"></span> Sending…';
    status.textContent = '';
    status.className = 'form-status';

    try {
      const formData = new FormData(contactForm);
      const response = await fetch(FORMSPREE_ENDPOINT, {
        method: 'POST',
        body: formData,
        headers: { 'Accept': 'application/json' }
      });

      if (response.ok) {
        status.textContent = "Message sent — I'll get back to you soon.";
        status.className = 'form-status ok';
        contactForm.reset();
      } else {
        const data = await response.json().catch(() => null);
        const message = data?.errors?.map(e => e.message).join(', ') || 'Something went wrong. Please try again or email me directly.';
        status.textContent = message;
        status.className = 'form-status err';
      }
    } catch (err) {
      status.textContent = 'Network error — please try again or email me directly.';
      status.className = 'form-status err';
    } finally {
      btn.disabled = false;
      btn.innerHTML = originalBtnText;
    }
  });
}
